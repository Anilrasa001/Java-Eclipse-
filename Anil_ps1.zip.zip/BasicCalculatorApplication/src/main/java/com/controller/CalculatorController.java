package com.controller;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
public class CalculatorController {
		@Bean
		public void addition a1(){
		return new addition(20,10);
		}
		@Autowired
		public ArithmaticService(Number1,Number2) {
			this.Number1= Number2;
			this.Number2=Number2;
		}
		@Bean
		public void substration addition s1() {
		return new substration(30,5);
		
		}
}
