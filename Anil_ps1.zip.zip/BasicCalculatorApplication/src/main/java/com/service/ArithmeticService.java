package com.service;

public class ArithmeticService {
	private static final String res11 = null;
	private static final String res12 = null;
	int Number1;
	int Number2;
	int res1=Number1+Number2; 
	int res2=Number1-Number2; 
	public static String addition() {
		return res11;
		
		
	}
	public static String substraction() {
		return res12;
		
	}
	
	}
	


