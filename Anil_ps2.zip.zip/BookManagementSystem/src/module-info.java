/**
 * 
 */
/**
 * 
 */
module JDBC_PROJECT {
	requires java.desktop;
	requires java.sql;
}