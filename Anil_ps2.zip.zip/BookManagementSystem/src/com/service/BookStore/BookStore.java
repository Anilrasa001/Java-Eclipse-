package com.service.BookStore;

public class BookStore {
	public void addBooks()
	{
		
	}

}
